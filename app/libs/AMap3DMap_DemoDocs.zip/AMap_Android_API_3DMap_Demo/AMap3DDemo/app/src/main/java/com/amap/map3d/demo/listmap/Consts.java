package com.amap.map3d.demo.listmap;

/**
 * Created by shixin on 2018/4/16.
 */

public class Consts {
    public static final int VIEWTYPE_TEXT = 0;
    public static final int VIEWTYPE_MAP = 1;
}
